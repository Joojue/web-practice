<?php
$num = $_POST['num'];
$unit = $_POST['unit'];

$row1 = '미터(m)';
$row2 = '인치(in)';
$row3 = '피트(ft)';
$row4 = '야드(yd)';

if ($unit == $row1) {
	$row1 = $num;
	$row2 = $num*39.3701;
	$row3 = $num*3.28084;
	$row4 = $num*1.09361;
}
elseif ($unit == $row2) {
	$row1 = $num*0.0254;
	$row2 = $num;
	$row3 = $num*0.0833333;
	$row4 = $num*0.0277778;
}
elseif ($unit == $row3) {
	$row1 = $num*0.3048;
	$row2 = $num*12;
	$row3 = $num;
	$row4 = $num*0.333333;
}
else {
	$row1 = $num*0.9144;
	$row2 = $num*36;
	$row3 = $num*3;
	$row4 = $num;
}
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>단위 변환기</title>
<style>
	table{
		border-width: 5px;
		border-style: solid;
		border-collapse: collapse;
		border-color: red;
		align: center;
	}
	th {
		width: 300px;
		border-color: red;
		border-style: solid;
	}
</style>
</head>
<body>
<h2>단위 변환기 : <?php echo $num?> <?php echo $unit ?></h2>
<table>
	<tr><th><?php echo round($row1, 4)?> 미터(m)</th></tr>
	<tr><th><?php echo round($row2, 4)?> 인치(in)</th></tr>
	<tr><th><?php echo round($row3, 4)?> 피트(ft)</th></tr>
	<tr><th><?php echo round($row4, 4)?> 야드(yd)</th></tr>
</table>
</body>
</html>